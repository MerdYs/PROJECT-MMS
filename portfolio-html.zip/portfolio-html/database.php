<?php

// Database configuratie
$host = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "portfolio-opdracht";

// Maak een database connectie
$conn = mysqli_connect($host, $dbuser, $dbpass, $dbname);