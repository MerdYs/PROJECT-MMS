<?php 

require 'database.php';

$naam = $_POST['naam'];
$email = $_POST['email'];
$onderwerp = $_POST['onderwerp'];
$beschrijving = $_POST['beschrijving'];

$sql = "INSERT INTO berichten (naam, email, onderwerp, beschrijving)
VALUES ('$naam', '$email', '$onderwerp', '$beschrijving')";

// Voer de INSERT INTO STATEMENT uit
mysqli_query($conn, $sql);

mysqli_close($conn); // Sluit de database verbinding
?>