<?php 

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CATEGORIE</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <h1>MAAK EEN CATEGORIE</h1>
      <form action="categorie-index.php" method="post">
        <div class="txt_field">
          <input type="text" name="naam" required>
          <span></span>
          <label>Naam</label>
        </div>
        <div class="txt_field">
          <textarea name="beschrijving" required>
          <span></span>
          <label>Beschrijving</label>
        </div>
        <input type="submit" value="Meld Bericht">
      </form>
    </div>
  </body>
</html>
