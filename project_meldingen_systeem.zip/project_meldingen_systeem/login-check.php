<?php 

require 'database.php';

$log_email = [];
$log_wachtwoord = [];

if(isset($_POST['log-email']) && ($_POST['log-wachtwoord'])){
    $log_email = $_POST["log-email"];
    $log_wachtwoord = $_POST["log-wachtwoord"];


    //de sql query
    $sql = "SELECT * FROM gebruikers WHERE email = '$log_email' AND wachtwoord = '$log_wachtwoord'";

    $resultaat = mysqli_query($conn, $sql);

    $gebruiker = mysqli_fetch_assoc($resultaat);

    if($gebruiker["rol"] == "personeelslid"){

        session_start();

        $_SESSION['gebruiker'] = $gebruiker;

        header("Location: account.php");
    }
    else if($gebruiker["rol"] == "gebruiker"){
        session_start();

        $_SESSION['gebruiker'] = $gebruiker;
        
        header("Location: account.php");
    }
    else{
        echo "rol bestaat niet";
        header("Location: login.php");
    }
}
?>