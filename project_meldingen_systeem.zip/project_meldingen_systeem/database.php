<?php

$host  = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "project-mms";
 
// Maak een  database connectie
$conn = mysqli_connect($host, $dbuser, $dbpass, $dbname);
?>