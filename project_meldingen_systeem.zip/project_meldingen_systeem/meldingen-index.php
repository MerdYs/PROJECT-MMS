<?php

require 'database.php';

$result = $conn->query("SELECT * FROM meldingen");
$categories = $result->fetch_all(MYSQLI_ASSOC);

$bericht = $conn ->real_escape_string($_POST['bericht']);
$categorie = $_POST['categorie'];
$opmerking = $conn ->real_escape_string($_POST['opmerking']);
$personeel_id = $conn ->real_escape_string($_POST['personeel_id']);
$id = $conn ->real_escape_string($_SESSION['id']);

$sql = "INSERT INTO meldingen (bericht, categorie_id, opmerking, gebruiker_id, personeel_id)
VALUES ('$bericht', '$categorie', '$opmerking', '$id', '$personeel_id')";

// Voer de INSERT INTO STATEMENT uit
mysqli_query($conn, $sql);

echo "Inserted successfully";
mysqli_close($conn); // Sluit de database verbinding
?>