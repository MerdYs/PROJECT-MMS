<?php

require 'database.php';

?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>MELDING</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <h1>MAAK EEN MELDING</h1>
      <form action="meldingen-index.php" method="post">

        <div class="txt_field">
          <input type="text" name="bericht" required>
          <span></span>
          <label>Bericht</label>
        </div>
        <?php 
          $result = $conn->query("SELECT * FROM categorieën");
          $categories = $result->fetch_all(MYSQLI_ASSOC);
        ?>        
        <select name="categorie" id="">
          <option selected>Kies een Categorie</option>
          <?php
          foreach($categories as $categorie):
          ?>
          <option value="<?php echo $categorie['id']  ?>"><?php echo $categorie['naam']  ?></option>
          <?php endforeach; ?>
        </select>
        <div class="txt_field">
          <input type="text" name="opmerking" required>
          <span></span>
          <label>Opmerking</label>
        </div>
        <div class="txt_field">
          <input type="text" name="personeel_id"> 
          <span></span>
          <label>Personeel</label>
        </div>
        <input type="submit" value="Meld Bericht">
      </form>
    </div>
  </body>
</html>
