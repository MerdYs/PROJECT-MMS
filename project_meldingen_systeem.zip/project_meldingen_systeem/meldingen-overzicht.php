<?php

require 'database.php';

//de sql query
$sql = "SELECT * FROM meldingen";

//hier wordt de query uitgevoerd met de database
$result = mysqli_query($conn,$sql);

/**
 * Hier wordt het resultaat ($result) omgezet 
 * in een *multidimensionale associatieve array 
 * in dit voorbeeld staat $all_users maar dit mag 
 * voor bijvoorbeeld producten $all_products heten. 
 * Maar dit kies je zelf
 */
$all_meldingen = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Meldingen</title>
</head>
<body>
    <table class="table">
       <thead>
            <th>ID</th>
            <th>Gebruiker_ID</th>
            <th>Bericht</th>
            <th>Status</th>
            <th>Categorie_ID</th>
            <th>Datum</th>
            <th>Opmerking</th>
            <th>Personeel_ID</th>
       </thead>
       
       <tbody>
            <?php foreach ($all_meldingen as $melding){ ?>
                <tr>
                    <td> <?php echo $melding["id"]?></td> 
                    <td> <?php echo $melding["gebruiker_id"]?></td>
                    <td> <?php echo $melding["bericht"]?></td>
                    <td> <?php echo $melding["status"]?></td>
                    <td> <?php echo $melding["categorie_id"]?></td>
                    <td> <?php echo $melding["datum"]?></td>
                    <td> <?php echo $melding["opmerking"]?></td>
                    <td> <?php echo $melding["personeel_id"]?></td>
                </tr>
                <?php } ?>
       </tbody>
    </table>
</body>
</html>