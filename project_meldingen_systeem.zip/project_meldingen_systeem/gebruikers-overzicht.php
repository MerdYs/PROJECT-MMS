<?php

require 'database.php';

//de sql query
$sql = "SELECT * FROM gebruikers";

//hier wordt de query uitgevoerd met de database
$result = mysqli_query($conn,$sql);

/**
 * Hier wordt het resultaat ($result) omgezet 
 * in een *multidimensionale associatieve array 
 * in dit voorbeeld staat $all_users maar dit mag 
 * voor bijvoorbeeld producten $all_products heten. 
 * Maar dit kies je zelf
 */
$all_gebruikers = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Gebruikers Lijst</title>
</head>
<body>
    <form action="login-check.php" method="post">
    <table class="table">
       <thead>
            <th>ID</th>
            <th>Voornaam</th>
            <th>Achternaam</th>
            <th>Email</th>
            <th>Wachtwoord</th>
            <th>Geboortedatum</th>
            <th>Telefoonnummer</th>
            <th>rol</th>
            <th></th>
       </thead>
       
       <tbody>
            <?php foreach ($all_gebruikers as $gebruiker){ ?>
                <tr>
                    <td> <?php echo $gebruiker["id"]?></td> 
                    <td> <?php echo $gebruiker["voornaam"]?></td>
                    <td> <?php echo $gebruiker["achternaam"]?></td>
                    <td> <?php echo $gebruiker["email"]?></td>
                    <td> <?php echo $gebruiker["wachtwoord"]?></td>
                    <td> <?php echo $gebruiker["geboortedatum"]?></td>
                    <td> <?php echo $gebruiker["telefoonnummer"]?></td>
                    <td> <?php echo $gebruiker["rol"]?></td>
                    <td><a href="deleteuser.php">Delete</a></td>
                </tr>
                <?php } ?>
       </tbody>
    </table>
</body>
</html>