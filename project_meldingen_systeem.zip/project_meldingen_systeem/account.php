<?php

require 'database.php';

session_start();

$gebruiker = $_SESSION['gebruiker'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="body">
<?php 

    if($gebruiker["rol"] == "personeelslid"){ ?>
    
    <div class="topnav">
        <h1 style="position: absolute;">Project Meldingen Systeem: Personeel</h1>
        <a class="active" href="login.php">Log uit</a>
        <a href="categorie-overzicht.php">Categorie Overzicht</a>
        <a href="gebruikers-overzicht.php">Gebruikers</a>
        <a href="meldingen-overzicht.php">Meldingen Overzicht</a>
    </div>
        
        <?php 
    }
    else if($gebruiker["rol"] == "gebruiker"){ ?>

    <div class="topnav">
        <h1 style="position: absolute;">Project Meldingen Systeem: Gebruiker</h1>
        <a class="active" href="login.php">Log Uit</a>
        <a href="meldingen-maak.php">Maak een Melding</a>
        <a href="categorie-maak.php">Maak een Categorie</a>
    </div>

    <?php } ?>
</div>
    <img src="Images/Logo_Nova_College.jpg" class="img1">
</body>
</html>