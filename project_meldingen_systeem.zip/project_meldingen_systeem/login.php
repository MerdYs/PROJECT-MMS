<?php

session_start();

require 'database.php';

$gebruikers = "SELECT * FROM gebruikers";

$result_gebruikers = mysqli_query($conn, $gebruikers);

$alle_gebruikers = mysqli_fetch_all($result_gebruikers, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Inloggen</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <h1>LOGIN</h1>
       <form action="login-check.php" method="post">
        <div class="txt_field">
          <input type="text" name="log-email" required>
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input type="password" name="log-wachtwoord" required>
          <span></span>
          <label>Wachtwoord</label>
        </div>
        <input type="submit" value="submit">
        <div class="signup_link">
          Nog geen account? <a href="registreer.php">Registreren</a>
        </div>
      </form>
    </div>

  </body>
</html>
