<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Registreren</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <h1>REGISTREER</h1>
      <form action="registreer-check.php" method="post">
        <div class="txt_field">
          <input type="text" name="voornaam" required>
          <span></span>
          <label>Voornaam</label>
        </div>
        <div class="txt_field">
          <input type="text" name="achternaam" required>
          <span></span>
          <label>Achternaam</label>
        </div>
        <div class="txt_field">
          <input type="email" name="email" required>
          <span></span>
          <label>E-Mail</label>
        </div>
        <div class="txt_field">
          <input type="password" name="wachtwoord" required>
          <span></span>
          <label>Wachtwoord</label>
        </div>
        <div class="txt_field">
          <input type="date" name="geboortedatum" required>
          <span></span>
          <label></label>
        </div>
        <div class="txt_field">
          <input type="tel" name="telefoonnummer" required>
          <span></span>
          <label>Telefoonnummer</label>
        </div>
        <div class="txt_field">
          <input type="text" name="rol" required>
          <span></span>
          <label>Kies Rol</label>
        </div>
        <input type="submit" value="Registreer">
        <div class="signup_link">
          Ga <a href="login.php">terug</a> naar het inloggen 
        </div>

      </form>
    </div>

  </body>
</html>
