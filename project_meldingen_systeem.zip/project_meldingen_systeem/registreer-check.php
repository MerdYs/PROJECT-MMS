<?php

require 'database.php';

$voornaam = $_POST['voornaam'];
$achternaam = $_POST['achternaam'];
$email = $_POST['email'];
$wachtwoord = $_POST['wachtwoord'];
$geboortedatum = $_POST['geboortedatum'];
$telefoonnummer = $_POST['telefoonnummer'];
$rol = $_POST['rol'];

$sql = "INSERT INTO gebruikers (voornaam, achternaam, email, wachtwoord, geboortedatum, telefoonnummer, rol)
VALUES ('$voornaam', '$achternaam', '$email', '$wachtwoord', '$geboortedatum', '$telefoonnummer', '$rol')";

// Voer de INSERT INTO STATEMENT uit
mysqli_query($conn, $sql);

mysqli_close($conn); // Sluit de database verbinding
?>