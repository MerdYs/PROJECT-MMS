<?php

require 'database.php';

$naam = $_POST['naam'];
$beschrijving = $_POST['beschrijving'];

$sql = "INSERT INTO categorieën (naam, beschrijving)
VALUES ('$naam', '$beschrijving')";

// Voer de INSERT INTO STATEMENT uit
mysqli_query($conn, $sql);

echo "Inserted successfully";
mysqli_close($conn); // Sluit de database verbinding
?>